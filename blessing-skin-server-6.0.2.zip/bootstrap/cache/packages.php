<?php return array (
  'blessing/filter' => 
  array (
    'providers' => 
    array (
      0 => 'Blessing\\FilterServiceProvider',
    ),
  ),
  'facade/ignition' => 
  array (
    'providers' => 
    array (
      0 => 'Facade\\Ignition\\IgnitionServiceProvider',
    ),
    'aliases' => 
    array (
      'Flare' => 'Facade\\Ignition\\Facades\\Flare',
    ),
  ),
  'intervention/image' => 
  array (
    'providers' => 
    array (
      0 => 'Intervention\\Image\\ImageServiceProvider',
    ),
    'aliases' => 
    array (
      'Image' => 'Intervention\\Image\\Facades\\Image',
    ),
  ),
  'laravel/passport' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Passport\\PassportServiceProvider',
    ),
  ),
  'lorisleiva/laravel-search-string' => 
  array (
    'providers' => 
    array (
      0 => 'Lorisleiva\\LaravelSearchString\\ServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'rcrowe/twigbridge' => 
  array (
    'providers' => 
    array (
      0 => 'TwigBridge\\ServiceProvider',
    ),
    'aliases' => 
    array (
      'Twig' => 'TwigBridge\\Facade\\Twig',
    ),
  ),
  'spatie/laravel-translation-loader' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\TranslationLoader\\TranslationServiceProvider',
    ),
  ),
);